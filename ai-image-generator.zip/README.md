# AI Image Generator 🎨

Generate stunning images just by describing them using this simple app powered by OpenAI DALL·E.

## 🚀 How to Run

1. Install dependencies:
    ```
    pip install -r requirements.txt
    ```

2. Set your OpenAI API key:
    - Windows:
      ```
      set OPENAI_API_KEY=your_api_key
      ```
    - Mac/Linux:
      ```
      export OPENAI_API_KEY=your_api_key
      ```

3. Start the app:
    ```
    streamlit run app.py
    ```

Type a creative prompt and enjoy the magic of AI-generated images!
